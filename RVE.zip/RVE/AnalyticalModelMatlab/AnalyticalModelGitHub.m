%Assume fvf braid =56 % something is off with the analytical model
Vf=0.63; %0.72 axial 0.63 bias
Vm= 1-Vf;
E11f= 230000; %axial modulus fiber
E22f= 15000; %Transverse modulus fiber
E33f= 15000;
Em = 4047;%matrix modulus
Gm = 1516; %shear matrix modulus;
vm=0.363;
G12f = 24000; %shear modulus fiber;
v12f = 0.2; %poisson;
v12m = vm;
v23f=0.491;
v23m=vm;

S12f = -v12f/E11f;
S12m = -v12m/Em;
S11f = 1/E11f;
S11m= 1/Em;
S22f = 1/E22f;
S22m = 1/Em;
S21f = S12f;
S21m = S12m;
S23f = -v23f/E33f;
S23m = -v23m/Em;
a11= Em/E11f;
a22= 0.5*(1+ Em/E22f);
a33=a22;
a44=a22;
a55=0.5*(1 + Gm/G12f);
a66=a55;
a12 = ((S12f-S12m)*(a11-a22))/(S11f-S11m);
a13 = a12;

E11 = Vf*E11f + Vm*Em;
v12 = Vf*v12f + Vm*vm;
v13 = v12;
E22 = ((Vf+Vm*a11)*(Vf+Vm*a22))/ ((Vf+Vm*a11)*(Vf*S22f+ a22*Vm*S22m) + Vf*Vm*(S21m-S21f)*a12);
E33 = E22;
G12 = Gm*((G12f+Gm)+Vf*(G12f-Gm))/((G12f+Gm)-Vf*(G12f-Gm));
G13 = G12;
G23 = 0.5*(Vf+Vm*a22)/((Vf*(S22f-S23f))+Vm*a22*(S22m-S23m));
v23 = 0.5*E22/G23 -1;
v32 = v23*E33/E22;
v21 = v12*E22/E11;
v31 = v13*E33/E11;


s11 = 1/E11;
s12 = -v12/E11;
s13 = -v13/E11;
s21 = s12;
s22 = 1/E22;
s23 = -v23/E33;
s31 = s13;
s32 = s23;
s33 = 1/E33;
s44 = 1/G23;
s55 = 1/G13;
s66 = 1/G12;

S = [s11 s12 s13 0 0 0 ; s21 s22 s23 0 0 0; s31 s32 s33 0 0 0; 0 0 0 s44 0 0; 0 0 0 0 s55 0; 0 0 0 0 0 s66];
C=S^-1;


rotationangle= pi()/3; 
ha = .299;
hb = .234;
A = (ha+hb)/2;
Lx = 18.006;
L = (Lx/cos(pi()/2 - rotationangle))/2;

syms xprime

zprime = A*sin(pi()*xprime/L);
tanb = (pi()*A/L) * cos(pi()*xprime/L);
m = 1/sqrt(1+tanb^2);
n = tanb/sqrt(1+tanb^2);

T1 = [m^2 0 n^2 0 2*m*n 0; 0 1 0 0 0 0; n^2 0 m^2 0 -2*m*n 0; 0 0 0 m 0 -n; -m*n 0 m*n 0 m^2-n^2 0; 0 0 0 n 0 m];
T2 = [m^2 0 n^2 0 m*n 0; 0 1 0 0 0 0; n^2 0 m^2 0 -m*n 0; 0 0 0 m 0 -n; -2*m*n 0 2*m*n 0 m^2-n^2 0; 0 0 0 n 0 m];
sigma = double((1/(2*L)) * int(T1^-1 * C * T2, xprime, 0, 2*L));


alpha = pi()/2 - rotationangle;

i = cos(alpha);
j = sin(alpha);
T3 = [i^2 j^2 0 0 0 2*i*j; j^2 i^2 0 0 0 -2*i*j; 0 0 1 0 0 0; 0 0 0 i -j 0; 0 0 0 j i 0; -i*j i*j 0 0 0 i^2-j^2];
T4 = [i^2 j^2 0 0 0 i*j; j^2 i^2 0 0 0 -i*j; 0 0 1 0 0 0; 0 0 0 i -j 0; 0 0 0 j i 0; -2*i*j 2*i*j 0 0 0 i^2-j^2];

sigmaprime = T3^-1 * sigma * T4

%%
%for -60 braid
alpha2 = pi/2 - rotationangle + 120*pi/180;
i = cos(alpha2);
j = sin(alpha2);
T3 = [i^2 j^2 0 0 0 2*i*j; j^2 i^2 0 0 0 -2*i*j; 0 0 1 0 0 0; 0 0 0 i -j 0; 0 0 0 j i 0; -i*j i*j 0 0 0 i^2-j^2];
T4 = [i^2 j^2 0 0 0 i*j; j^2 i^2 0 0 0 -i*j; 0 0 1 0 0 0; 0 0 0 i -j 0; 0 0 0 j i 0; -2*i*j 2*i*j 0 0 0 i^2-j^2];
sigmaprime2 = T3^-1 * sigma * T4

%% for axial braid at 90
Vf=0.72; %0.72 axial 0.63 bias
Vm= 1-Vf;
E11f= 230000; %axial modulus fiber
E22f= 15000; %Transverse modulus fiber
E33f= 15000;
Em = 4047;%matrix modulus
Gm = 1516; %shear matrix modulus;
vm=0.363;
G12f = 24000; %shear modulus fiber;
v12f = 0.2; %poisson;
v12m = vm;
v23f=0.491;
v23m=vm;

S12f = -v12f/E11f;
S12m = -v12m/Em;
S11f = 1/E11f;
S11m= 1/Em;
S22f = 1/E22f;
S22m = 1/Em;
S21f = S12f;
S21m = S12m;
S23f = -v23f/E33f;
S23m = -v23m/Em;
a11= Em/E11f;
a22= 0.5*(1+ Em/E22f);
a33=a22;
a44=a22;
a55=0.5*(1 + Gm/G12f);
a66=a55;
a12 = ((S12f-S12m)*(a11-a22))/(S11f-S11m);
a13 = a12;

E11 = Vf*E11f + Vm*Em;
v12 = Vf*v12f + Vm*vm;
v13 = v12;
E22 = ((Vf+Vm*a11)*(Vf+Vm*a22))/ ((Vf+Vm*a11)*(Vf*S22f+ a22*Vm*S22m) + Vf*Vm*(S21m-S21f)*a12);
E33 = E22;
G12 = Gm*((G12f+Gm)+Vf*(G12f-Gm))/((G12f+Gm)-Vf*(G12f-Gm));
G13 = G12;
G23 = 0.5*(Vf+Vm*a22)/((Vf*(S22f-S23f))+Vm*a22*(S22m-S23m));
v23 = 0.5*E22/G23 -1;
v32 = v23*E33/E22;
v21 = v12*E22/E11;
v31 = v13*E33/E11;


s11 = 1/E11;
s12 = -v12/E11;
s13 = -v13/E11;
s21 = s12;
s22 = 1/E22;
s23 = -v23/E33;
s31 = s13;
s32 = s23;
s33 = 1/E33;
s44 = 1/G23;
s55 = 1/G13;
s66 = 1/G12;

S = [s11 s12 s13 0 0 0 ; s21 s22 s23 0 0 0; s31 s32 s33 0 0 0; 0 0 0 s44 0 0; 0 0 0 0 s55 0; 0 0 0 0 0 s66];
C=S^-1;

rotationangle= pi()/3; 
ha = .299;
A = (.510-ha)/2;%measured amplitude-axialthickness / 2
Ly = 10.030/2;
L = Ly/2;

syms xprime

zprime = A*sin(pi()*xprime/L);
tanb = (pi()*A/L) * cos(pi()*xprime/L);
m = 1/sqrt(1+tanb^2);
n = tanb/sqrt(1+tanb^2);

T1 = [m^2 0 n^2 0 2*m*n 0; 0 1 0 0 0 0; n^2 0 m^2 0 -2*m*n 0; 0 0 0 m 0 -n; -m*n 0 m*n 0 m^2-n^2 0; 0 0 0 n 0 m];
T2 = [m^2 0 n^2 0 m*n 0; 0 1 0 0 0 0; n^2 0 m^2 0 -m*n 0; 0 0 0 m 0 -n; -2*m*n 0 2*m*n 0 m^2-n^2 0; 0 0 0 n 0 m];
sigma = double((1/(2*L)) * int(T1^-1 * C * T2, xprime, 0, 2*L));


alpha3 = pi()/2;

i = cos(alpha3);
j = sin(alpha3);
T3 = [i^2 j^2 0 0 0 2*i*j; j^2 i^2 0 0 0 -2*i*j; 0 0 1 0 0 0; 0 0 0 i -j 0; 0 0 0 j i 0; -i*j i*j 0 0 0 i^2-j^2];
T4 = [i^2 j^2 0 0 0 i*j; j^2 i^2 0 0 0 -i*j; 0 0 1 0 0 0; 0 0 0 i -j 0; 0 0 0 j i 0; -2*i*j 2*i*j 0 0 0 i^2-j^2];

sigmaprime3 = T3^-1 * sigma * T4
%%
%summing the averages to get the global stiffness matrix value

Vola = 34.97; %mm^3
Volb = 62.50;
Volm = 21.18;
thickness = .657;
Vol= Lx*Ly*2*thickness;
Sm = [1/Em -vm/Em -vm/Em 0 0 0; -vm/Em 1/Em -vm/Em 0 0 0; -vm/Em -vm/Em 1/Em 0 0 0; 0 0 0 1/Gm 0 0; 0 0 0 0 1/Gm 0; 0 0 0 0 0 1/Gm];
Cm = Sm^-1;
Ceq = (1/3)*(sigmaprime3 + sigmaprime + sigmaprime2);
Seq = Ceq^-1;

%As is Analytical for 56% FVF
%Cvol = 0.2633*sigmaprime3 + 0.2633*sigmaprime + 0.2633*sigmaprime2 + 0.2101*Cm 

%Calibrated for 48% FVF
Cvol = 0.2424*sigmaprime3 + 0.2424*sigmaprime + 0.2424*sigmaprime2 + 0.2727*Cm %for a 48% FVF RVE
Svol = Cvol^-1

HomE11 = Svol(1,1)^-1
HomE22 = Svol(2,2)^-1 
HomE33 = Svol(3,3)^-1
HomG12 = Svol(6,6)^-1
HomG23 = Svol(4,4)^-1
Homv12 = -Svol(1,2)*HomE11
Homv13 = -Svol(2,3)*HomE22

