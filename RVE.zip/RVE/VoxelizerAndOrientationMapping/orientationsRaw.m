%Code assumes second vector (y) is perfectly to the horizontal left of the yarn path
%(vertical yarn, y vector is in global x. x vector is along fiber
%direction. x vector is changing along the b spline to cause the surface
%normal z vector to change.)

%[f v]=stlread('1.stl');
%patch('Faces',f,'Vertices',v,'FaceColor','red')
disp('starting orientation calculations')
FID = 'orientations.txt';
elcount = 1;
%vector for x
oriBase = [0; 1];
%vector for y, makes z vector point upward.
oriAxial2 = [-1, 0, 0]*[[cosd(rveAngle), -sind(rveAngle), 0; sind(rveAngle), cosd(rveAngle), 0; 0, 0, 1]];
aP = 90-angle-rveAngle;
aM = 90+angle-rveAngle;
%RotateM = [cosd(angle), -sind(angle); sind(angle), cosd(angle)];
oriPrimeP = [[cosd(aP), -sind(aP); sind(aP), cosd(aP)]*oriBase; 0]';
oriPrimeM = [[cosd(aM), -sind(aM); sind(aM), cosd(aM)]*oriBase; 0]';
for i = 1:nYarns
    i
    tic
    m=int2str(i);
    [f vert]=stlread(strcat(m,'.stl'));
    FV=stlread(strcat(m,'.stl'));
    %Vertex normals of a triangulated mesh, area weighted, left-hand-rule
    % N = patchnormals(FV) -struct with fields, faces Nx3 and vertices Mx3
    %N: vertex normals as Mx3
    %Need to find the surface normals of each stl face on surface, done by
    %doing a cross product between the vertice points on the face. 
    %face corners index
    A = FV.faces(:,1);
    B = FV.faces(:,2);
    C = FV.faces(:,3);
    %face normals
    n = cross(FV.vertices(A,:)-FV.vertices(B,:),FV.vertices(C,:)-FV.vertices(A,:)); %area weighted
    %vertice normals
    N = zeros(size(FV.vertices)); %init vertix normals
    for ii = 1:size(FV.faces,1) %step through faces (a vertex can be reference any number of times)
        N(A(ii),:) = N(A(ii),:)+n(ii,:); %sum face normals
        N(B(ii),:) = N(B(ii),:)+n(ii,:);
        N(C(ii),:) = N(C(ii),:)+n(ii,:);
    end
    j=1;
    loopHold = 1;
    while loopHold==1
        if elset(i,j)==0
            loopHold=0;
        else
            els = elset(i,j);
            j=j+1;
            origin = centroid(els,:);
            %%% this value should be sufficient but change as thickness values
            %%% change. 
            direction = origin + [0 0 range(domainz)+1];
            flag = 0;
            k=1;
            while flag==0
                v0 = vert(f(k,1),:);
                v1 = vert(f(k,2),:);
                v2 = vert(f(k,3),:);
                [flag, u, v, t] = rayTriangleIntersection(origin, direction, v0, v1, v2);
                if flag==1
                    %flagged as face intersection! find orientations
                    if ismember(i,nYAxial)==1
                        normal = N(f(k,1),:);
                        if normal(1,3)<0
                            normal=-normal;
                        end
                        oriAxial1 = -cross(normal,oriAxial2);
                        ori(elcount,:) = [els oriAxial1 oriAxial2];
                        elcount = elcount+1;
                    elseif ismember(i,nYPlus)==1
                        normal = N(f(k,1),:);
                        if normal(1,3)<0
                            normal=-normal;
                        end
                        oriP1 = -cross(normal,oriPrimeP);
                        ori(elcount,:) = [els oriP1 oriPrimeP];
                        elcount = elcount+1;
                    elseif ismember(i,nYMin)==1
                        normal = N(f(k,1),:);
                        if normal(1,3)<0
                            normal=-normal;
                        end
                        oriP2 = -cross(normal,oriPrimeM);
                        ori(elcount,:) = [els oriP2 oriPrimeM];
                        elcount = elcount+1;
                    end
                else
                    %no face intersection flagged, continue through faces.
                    k=k+1;
                end
            end
        end
        if j==length(elset)
            loopHold=0;
        end
    end
    toc
end
%sort rows
oriSort=sortrows(ori);
fileID=FID;
fileID = fopen(fileID,'w');
fprintf(fileID,', 1, 0, 0, 0, 1, 0');
fclose(fileID);
writematrix(oriSort, FID,'writemode','append');
%writematrix(oriSort, FID);
    