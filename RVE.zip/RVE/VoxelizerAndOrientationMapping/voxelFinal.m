%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Code to create a voxel grid
%03/24/2020
%fixed Odd elements only problem
%Marisa Bisram
%Centroid is the centroid of voxel elements
%elset is the element count in the voxel bunch and which yarns they belong
%to (assembling elements into yarns). 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
format long
%Coordinates of bottom left corner node 75593 :-1.88854,-937.E-03,789.E-03
%Can Be Odd or Even!! Fixed Version!!!
%Numbers do not have to match!!!
%z can be any odd or even 
%number of elements
nx=100;
ny=100;
nz=50;
%total number of yarns
nYarns=83;
%separate yarn stl into axial, plus or minus angled. 
%enter yarn number for the categories
nYAxial = [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15];
nYPlus = [16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43];
nYMin = [44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 61 62 63 64 65 66 67 68 69 70 71 72 73 74 75 76 77 78 79 80 81 82 83];
%braid angle degrees
angle = 60;
%rve rotation angle
rveAngle= 60;
%rve rotation matrix
rz=[cosd(rveAngle) -sind(rveAngle) 0; sind(rveAngle) cosd(rveAngle) 0; 0 0 1];
%FileName yn xn zn
fileName = 'trial.inp';
%Domain boundaries in mm -1.88 to 16.123, 0 to 10.03
%lx = 18.003*cosd(rveAngle);
lx=17.37;
%-1.88
dx=9.436805;
%0
dy=-15.061438;
domainx=linspace(dx,dx+(lx/cosd(rveAngle)),nx+1);
%ly = 10.03*cosd(rveAngle);
ly=10.03;
domainy=linspace(dy,dy+(ly/cosd(rveAngle)),ny+1);
%Thickness is .652817 mm
%Compressed RVE domain:
%8.26410e-01, 1.73593e-01,
%Added 10% to domain thickness?
%domainz=linspace(0.8665,0.1365,nz+1);
domainz=linspace(0.83,0.173,nz+1);
[x y]=meshgrid(domainx, domainy);
z = domainz;

%%
%Section 1, Define nodal coordinates
%%moves xyz xy+1z x+1y+1z x+1yz................
%%%Does all the z's first then changes y
%%%Does all the y's first then changes x
disp('define nodal coordinates')
tic
t=1;
i=1;
count=1;
count2=1;
while i <= nx+1
    j=1;
    while j <= ny+1
        k=1;
        while k <= nz+1
            if j<ny+1 && i<nx+1
                nodes(t,:)= [domainx(i) domainy(j) domainz(k)];
                t = t+1;
                nodes(t,:)= [domainx(i) domainy(j+1) domainz(k)];
                t = t+1;
                nodes(t,:)= [domainx(i+1) domainy(j+1) domainz(k)];
                t = t+1;
                nodes(t,:)= [domainx(i+1) domainy(j) domainz(k)];
                t = t+1;
                k = k+1;
            elseif j==ny+1 && i<nx+1
                nodes(t,:)= [domainx(i) domainy(j) domainz(k)];
                t = t+1;
                nodes(t,:)= [domainx(i+1) domainy(j) domainz(k)];
                t = t+1;
                k = k+1;
            elseif j<ny+1 && i==nx+1
                nodes(t,:)= [domainx(i) domainy(j) domainz(k)];
                t = t+1;
                nodes(t,:)= [domainx(i) domainy(j+1) domainz(k)];
                t = t+1;
                k = k+1;
            elseif j==ny+1 && i==nx+1
                nodes(t,:)= [domainx(i) domainy(j) domainz(k)];
                t = t+1;
                k = k+1;
            end
        end
        j = j+2;
        if rem(ny,2)==0 && count==1
            if j>ny
                j=ny+1;
                count=0;
            end
        end
    end
    i = i+2;
    count=1;
    if rem(nx,2)==0 && count2==1
            if i>nx
                i=nx+1;
                count2=0;
            end
    end
end
toc

%%
%Section 2 define element block of nodal coordinate numbers
%moves xyz xy+1z x+1y+1z x+1yz
%IDK why, but it both this and section 1 matched in the order the elements
%wouldn't form.........
%%Moves down z's, then y's, then x's to form elements. If it does x's
%%before y's it is some trasnparent stuff elements. 
disp('define element blocks of nodal coordinates')
tic
tt=1;
jj=1;
c=1;
cc=1;
while jj <= nx+1
    ii=1;
    while ii <= ny+1
        kk=1;
        while kk <= nz+1
            if ii<ny+1 && jj<nx+1
                nMatrix(jj,ii,kk) = tt;
                tt = tt+1;
                nMatrix(jj,ii+1,kk) = tt;
                tt = tt+1;
                nMatrix(jj+1,ii+1,kk) = tt;
                tt = tt+1;
                nMatrix(jj+1,ii,kk) = tt;
                tt = tt+1;
                kk = kk+1;
            elseif ii==ny+1 && jj<nx+1
                nMatrix(jj,ii,kk)= tt;
                tt = tt+1;
                nMatrix(jj+1,ii,kk)= tt;
                tt = tt+1;
                kk = kk+1;
            elseif ii<ny+1 && jj==nx+1
                nMatrix(jj,ii,kk)= tt;
                tt = tt+1;
                nMatrix(jj,ii+1,kk)= tt;
                tt=tt+1;
                kk = kk+1;
            elseif ii==ny+1 && jj==nx+1
                nMatrix(jj,ii,kk)= tt;
                tt = tt+1;
                kk = kk+1;
            end
        end
        ii = ii+2;
        if rem(ny,2)==0 && c==1
            if ii>ny
                ii=ny+1;
                c=0;
            end
        end
    end
    jj = jj+2;
    c=1;
    if rem(nx,2)==0 && cc==1
            if jj>nx
                jj=nx+1;
                cc=0;
            end
    end
end
toc
%%
%Section 3 Create element definitions
%Writes the elements z, y, then x. Same order as all the above. xyz xy+1z
%x+1y+1z x+1yz
disp('create element definitions')
tic
ttt=1;
for k = 1:nx
    for j = 1:ny
        for m = 1:nz
            element(ttt,:)=[nMatrix(k,j,m) nMatrix(k,j+1,m) nMatrix(k+1,j+1,m) nMatrix(k+1,j,m)...
                nMatrix(k,j,m+1) nMatrix(k,j+1,m+1) nMatrix(k+1,j+1,m+1) nMatrix(k+1,j,m+1)];
            ttt = ttt+1;
        end
    end
end
toc
%%
%Section 4 write to .inp file
disp('write to .inp')
tic
fileID = fopen(fileName,'wt+');
fprintf(fileID,'%s\n','*NODE, NSET=all');

for i = 1:length(nodes)
    fprintf(fileID,'%d, %4.5f, %4.5f, %4.5f\n',i,nodes(i,1),nodes(i,2),nodes(i,3));
end

fprintf(fileID,'%s\n','*ELEMENT, TYPE=C3D8R, ELSET=AllElements');

for i = 1:length(element)
    fprintf(fileID,'%d, %d, %d, %d, %d, %d, %d, %d, %d\n',i,element(i,1),element(i,2),element(i,3),element(i,4),element(i,5),element(i,6),element(i,7),element(i,8));
end
toc
%%
disp('begin centroid calculations')
tic
centroid = [];
nElement = length(element);
for i = 1:nElement
    for j = 1:8
        xP(i,j) = nodes(element(i,j),1);
        yP(i,j) = nodes(element(i,j),2);
        zP(i,j) = nodes(element(i,j),3);
    end
end
xC = mean(xP');
yC = mean(yP');
zC = mean(zP');

for i = 1:nElement
    centroid(i,1)=xC(i);
    centroid(i,2)=yC(i);
    centroid(i,3)=zC(i);
end
toc
disp('reading yarns')
tic
for i = 1:nYarns
    yarn=i
    tic
    j=int2str(i);
    fv=stlread(strcat(j,'.stl'));
    %to view patch data
    %trimesh(f, v(:,1), v(:,2), v(:,3))
    in=inpolyhedron(fv,centroid);
    elsetBin(:,i)=in;
    toc
end
disp('total yarn read time')
toc
for i = 1:nYarns
    t=1;
    for j = 1:nElement
        if elsetBin(j,i)==1
            elset(i,t)=j;
            t = t+1;
        end
    end
end

z=1;
for i=1:nElement
    matrixIn= ismember(i,elset);
    if matrixIn==0
        matrixElset(1,z)=i;
        z=z+1;
    end
end
%%
disp('writing Yarns') 
for i = 1:length(elset(:,1))
    M=[];
    for j =1:length(elset)
        if elset(i,j)~=0
            M(1,j)=elset(i,j);
        end
    end
    fprintf(fileID,'%s\n',strcat('*Elset, elset= Yarn',int2str(i)));
    k=1;
    if length(M)<10
        %sometime the yarns aren't in the domain and will cause this error
        disp('error1 in writing elsets, increase element numbers nx ny nz')
    end
    while k <= length(M)
        MM=[];
        for L = 1:10
            if k <=length(M)
                MM(1,L)=M(1,k);
                k=k+1;
            end
        end
        string=strjoin(arrayfun(@(x) num2str(x),MM,'UniformOutput',false),', ');
        fprintf(fileID,'%s\n', string);
    end
end

disp('writing Matrix')
fprintf(fileID,'%s\n',strcat('*Elset, elset= Matrix'));
if length(matrixElset)<10
    disp('error2 in writing matrix elsets, increase element numbers nx ny nz')
end
k=1;
while k <= length(matrixElset)
    MM=[];
    for L = 1:10
        if k <=length(matrixElset)
            MM(1,L)=matrixElset(1,k);
            k=k+1;
        end
    end
    string=strjoin(arrayfun(@(x) num2str(x),MM,'UniformOutput',false),', ');
    fprintf(fileID,'%s\n', string);
end
fclose(fileID);
%Saves variable workspace so can run orientations file later!
save('trial.mat');