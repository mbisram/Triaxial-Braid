from TexGen.Core import *
import math
ta = 0.299
wa = 5.513
#angle from horizontal. So 60 degree braid is 30 degree from horizontal
#texgen already has math functions imported.
braidangle = pi/3
teta = pi/2 - braidangle
tb = 0.234
#wb in the drawing
wby = 4.879
sa = 9.003
sbyreal = 5.015
sb = sa*cos(braidangle)
sby = sb/cos(teta)
z = 1.0
sb = sby*cos(teta)
wb = wby*cos(teta)
ybound = 20
xbound = 20

axial = 1
ybraids = 1
while (wa + sa*(axial))<=xbound+sa:
    axial+=1
while (sby*(ybraids-1))<=ybound+sby:
    ybraids+=1
ybraidsp = ybraids
ybraidspn = axial
ybraidsn = ybraidsp + ybraidspn
xbraids = (axial-1)*2

n = axial + ybraidsp + ybraidspn+ ybraidsn

# Create a textile
Textile = CTextile()

# Create a python list containing yarns
Yarns = []
for i in range(0,n,1):
    Yarns.append(CYarn())

# Add nodes to the yarns to describe their paths
#First define axial yarns 

for i in range(0,axial,1):
    Yarns[i].AddNode(CNode(XYZ(sa*i+(sa/4), -ybound, z/2)))
    Yarns[i].AddNode(CNode(XYZ(sa*i+(sa/4), 2.5*ybound, z/2)))
    
#Positive angled yarns
t=1
for i in range(axial, axial+ybraidspn,1):
    x = 0
    while x <= xbound+sa:
        if x==0:
            Yarns[i].AddNode(CNode(XYZ(x+(wa-sa), (x+wa-sa)*tan(teta) - t*sby, 0)))
            #Yarns[i].AddNode(CNode(XYZ(x+(wa-sa)/2, (x+(wa-sa)/2)*tan(teta) - t*sby, z/2)))
            Yarns[i].AddNode(CNode(XYZ(x, -t*sby, z)))
        Yarns[i].AddNode(CNode(XYZ(x+wa, (x+wa)*tan(teta) - t*sby, z)))
        #Yarns[i].AddNode(CNode(XYZ(x+wa+(sa-wa)/2, (x+wa+(sa-wa)/2)*tan(teta) - t*sby, z/2)))
        Yarns[i].AddNode(CNode(XYZ(x+sa, (x+sa)*tan(teta) - t*sby, 0)))
        Yarns[i].AddNode(CNode(XYZ(x+sa+wa, (x+sa+wa)*tan(teta) - t*sby, 0)))
        #Yarns[i].AddNode(CNode(XYZ(x+sa+wa+(sa-wa)/2, (x+sa+wa+(sa-wa)/2)*tan(teta) - t*sby, z/2)))
        Yarns[i].AddNode(CNode(XYZ(x+2*sa, (x+2*sa)*tan(teta) - t*sby, z)))
        x=x+2*sa
    t=t+1
t=0
for i in range(axial+ybraidspn, axial+ybraidspn+ybraidsp,1):
    x = 0
    while x <= xbound+sa:
        if x==0:
            Yarns[i].AddNode(CNode(XYZ(x+wa-sa, (x+wa-sa)*tan(teta) + t*sby, 0)))
            #Yarns[i].AddNode(CNode(XYZ(x+(wa-sa)/2, (x+(wa-sa)/2)*tan(teta) + t*sby, z/2)))
            Yarns[i].AddNode(CNode(XYZ(x, t*sby, z)))
        Yarns[i].AddNode(CNode(XYZ(x+wa, (x+wa)*tan(teta) + t*sby, z)))
        #Yarns[i].AddNode(CNode(XYZ(x+wa+(sa-wa)/2, (x+wa+(sa-wa)/2)*tan(teta) + t*sby, z/2)))
        Yarns[i].AddNode(CNode(XYZ(x+sa, (x+sa)*tan(teta) + t*sby, 0)))
        Yarns[i].AddNode(CNode(XYZ(x+sa+wa, (x+sa+wa)*tan(teta) + t*sby, 0)))
        #Yarns[i].AddNode(CNode(XYZ(x+sa+wa+(sa-wa)/2, (x+sa+wa+(sa-wa)/2)*tan(teta) + t*sby, z/2)))
        Yarns[i].AddNode(CNode(XYZ(x+2*sa, (x+2*sa)*tan(teta) + t*sby, z)))
        x=x+2*sa
    t=t+1
    
    
#Negative angled yarns
t=0
for i in range(axial+ ybraidspn + ybraidsp, axial+ybraidspn+ybraidsp+ybraidsn,1):
    x = 0
    while x <= xbound+sa:
        if x==0:
            Yarns[i].AddNode(CNode(XYZ(x+wa-sa, -(x+wa-sa)*tan(teta) + t*sby, z)))
            #Yarns[i].AddNode(CNode(XYZ(x+(wa-sa)/2, -(x+(wa-sa)/2)*tan(teta) + t*sby, z/2)))
            Yarns[i].AddNode(CNode(XYZ(x, t*sby, 0)))
        Yarns[i].AddNode(CNode(XYZ(x+wa, -(x+wa)*tan(teta) + t*sby, 0)))
        #Yarns[i].AddNode(CNode(XYZ(x+wa+(sa-wa)/2, -(x+wa+(sa-wa)/2)*tan(teta) + t*sby, z/2)))
        Yarns[i].AddNode(CNode(XYZ(x+sa, -(x+sa)*tan(teta) + t*sby, z)))
        Yarns[i].AddNode(CNode(XYZ(x+sa+wa, -(x+sa+wa)*tan(teta) + t*sby, z)))
        #Yarns[i].AddNode(CNode(XYZ(x+sa+wa+(sa-wa)/2, -(x+sa+wa+(sa-wa)/2)*tan(teta) + t*sby, z/2)))
        Yarns[i].AddNode(CNode(XYZ(x+2*sa, -(x+2*sa)*tan(teta) + t*sby, 0)))
        x=x+2*sa
    t=t+1

#changing width to make thinner width
wb = 2.5
#wa = 4.0
# Create a lenticular section for the +- angled yarns
AngledSection = CSectionEllipse(wb, tb)

# The section will be rotated at the appropriate points to avoid interference
# So create an interpolated yarn section
AngledYarnSection = CYarnSectionInterpPosition(True, True)
# This is the rotation angle defined
RotationAngle = math.radians(14)

# Add rotated sections at 1/8 and 5/8 of the way along the yarn
# at angles of +- RotationAngle
t=0
i=2
while t<=x:  
    if t==0:
        AngledYarnSection.AddSection((-wa/2 + sa/2)/(x+ sa - wa), CSectionRotated(AngledSection, -RotationAngle))
        AngledYarnSection.AddSection((wa/2 + sa/2 + sa - wa)/(x+ sa - wa), CSectionRotated(AngledSection, +RotationAngle))
        AngledYarnSection.AddSection((wa/2 + 3*sa/2 + sa - wa)/(x+ sa - wa), CSectionRotated(AngledSection, -RotationAngle))
        t = t + wa/2 + 3*sa/2
    AngledYarnSection.AddSection((wa/2 + sa/2 + sa*i + sa - wa)/(x+ sa - wa), CSectionRotated(AngledSection, +RotationAngle))
    AngledYarnSection.AddSection((wa/2 + sa/2 + sa*(i+1) + sa - wa)/(x+ sa - wa), CSectionRotated(AngledSection, -RotationAngle))
    t = t + (wa/2 + sa/2 + sa*(i+1))
    i = i+2


# Add unrotated sections to the interpolation at intervals of 1/4
t=0
i=1
while t<=x:  
    if t==0:
        AngledYarnSection.AddSection(0.0, AngledSection)
        AngledYarnSection.AddSection((sa - wa)/(x+ sa - wa), AngledSection)
        AngledYarnSection.AddSection((wa + sa - wa)/(x+ sa - wa), AngledSection)
        t = t + wa
    AngledYarnSection.AddSection((sa*i + sa - wa)/(x+ sa - wa), AngledSection)
    AngledYarnSection.AddSection((sa*i + wa + sa - wa) /(x+ sa - wa), AngledSection)
    t = t + sa
    i = i+1

#Assign the rotating cross-section to the angled yarns
for i in range(axial,axial+ybraidspn+ybraidsp+ybraidsn,1):
    Yarns[i].AssignSection(AngledYarnSection)

# Create a lenticular section for the straight yarns and assign it
StraightSection = CSectionEllipse(wa, ta)
for i in range(0,axial,1):
    Yarns[i].AssignSection(CYarnSectionConstant(StraightSection))

# Loop over all the yarns in the list
for Yarn in Yarns:
    # Set the interpolation function
    Yarn.AssignInterpolation(CInterpolationCubic())
    # Set the resolution of the surface mesh created
    Yarn.SetResolution(100)
	# Add common repeat vector to the yarn
    #Yarn.AddRepeat(XYZ(12.0060, 0, 0))
    # Add the yarn to our textile
    Textile.AddYarn(Yarn)

# Create a domain and assign it to the textile
Textile.AssignDomain(CDomainPlanes(XYZ(-0.25,-0.25, 0-(z*0.4)), XYZ((sa*2)*1 +0.25, (sby*2)*1 +0.25, z+(z*0.4))))

# Add the textile
AddTextile("triaxialbraid1", Textile)